package edu.elon.bhaggerty.AuctionSeller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctionSellerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuctionSellerApplication.class, args);
	}

}
