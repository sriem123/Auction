package edu.elon.bhaggerty.AuctionSeller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionSellerApplicationTests {

	@Test
	void contextLoads() {
	}

}
