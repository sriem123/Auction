package edu.elon.bhaggerty.AuctionBidder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionBidderApplicationTests {

	@Test
	void contextLoads() {
	}

}
