package edu.elon.bhaggerty.AuctionBidder.models.notification;


import com.fasterxml.jackson.annotation.JsonProperty;

public class NotificationMessageAttribute {
    @JsonProperty("Type")
    private String type;

    @JsonProperty("Value")
    private String value;

    @JsonProperty("Type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("Value")
    public void setValue(String value) {
        this.value = value;
    }

    public String getType() {
        return this.type;
    }

    public String getValue() {
        return this.value;
    }
}
