package edu.elon.bhaggerty.AuctionBidder.models;

public class BidderInfo {
    private String acceptedBidsQueueUrl;

    private String forSaleMessageQueueUrl;

    private String forSaleSubscriptionId;

    private String auctionCompleteMessageQueueUrl;

    private String auctionCompleteSubscriptionId;

    public BidderInfo() {}

    public BidderInfo(String acceptedBidsQueueUrl, String forSaleMessageQueueUrl, String forSaleSubscriptionId, String auctionCompleteMessageQueueUrl, String auctionCompleteSubscriptionId) {
        this.acceptedBidsQueueUrl = acceptedBidsQueueUrl;
        this.forSaleMessageQueueUrl = forSaleMessageQueueUrl;
        this.forSaleSubscriptionId = forSaleSubscriptionId;
        this.auctionCompleteMessageQueueUrl = auctionCompleteMessageQueueUrl;
        this.auctionCompleteSubscriptionId = auctionCompleteSubscriptionId;
    }

    public void setAcceptedBidsQueueUrl(String acceptedBidsQueueUrl) {
        this.acceptedBidsQueueUrl = acceptedBidsQueueUrl;
    }

    public void setForSaleMessageQueueUrl(String forSaleMessageQueueUrl) {
        this.forSaleMessageQueueUrl = forSaleMessageQueueUrl;
    }

    public void setForSaleSubscriptionId(String forSaleSubscriptionId) {
        this.forSaleSubscriptionId = forSaleSubscriptionId;
    }

    public void setAuctionCompleteMessageQueueUrl(String auctionCompleteMessageQueueUrl) {
        this.auctionCompleteMessageQueueUrl = auctionCompleteMessageQueueUrl;
    }

    public void setAuctionCompleteSubscriptionId(String auctionCompleteSubscriptionId) {
        this.auctionCompleteSubscriptionId = auctionCompleteSubscriptionId;
    }

    public String getAcceptedBidsQueueUrl() {
        return this.acceptedBidsQueueUrl;
    }

    public String getForSaleMessageQueueUrl() {
        return this.forSaleMessageQueueUrl;
    }

    public String getForSaleSubscriptionId() {
        return this.forSaleSubscriptionId;
    }

    public String getAuctionCompleteMessageQueueUrl() {
        return this.auctionCompleteMessageQueueUrl;
    }

    public String getAuctionCompleteSubscriptionId() {
        return this.auctionCompleteSubscriptionId;
    }
}