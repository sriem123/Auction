package edu.elon.bhaggerty.AuctionBidder.configuration;

import edu.elon.bhaggerty.AuctionBidder.services.BidderService;
import edu.elon.bhaggerty.AuctionBidder.services.aws.MessageNotificationService;
import edu.elon.bhaggerty.AuctionBidder.services.aws.MessageQueueService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.awssdk.services.sns.SnsClientBuilder;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.SqsClientBuilder;

@Configuration
@PropertySources({@PropertySource({"classpath:application.properties"}), @PropertySource(value = {"file:application.properties"}, ignoreResourceNotFound = true)})
public class AWSConfig {
    @Value("${aws.region}")
    private String awsRegion;

    @Value("${aws.accessKey}")
    private String awsAccessKey;

    @Value("${aws.secretKey}")
    private String awsSecretKey;

    @Value("${aws.sessionToken}")
    private String awsSessionToken;

    @Bean
    public SnsClient snsClient() {
        AwsSessionCredentials credentials = AwsSessionCredentials.create(this.awsAccessKey, this.awsSecretKey, this.awsSessionToken);
        return (SnsClient)((SnsClientBuilder)((SnsClientBuilder)SnsClient.builder()
                .region(Region.of(this.awsRegion)))
                .credentialsProvider(() -> credentials))
                .build();
    }

    @Bean
    public SqsClient sqsClient() {
        AwsSessionCredentials credentials = AwsSessionCredentials.create(this.awsAccessKey, this.awsSecretKey, this.awsSessionToken);
        return (SqsClient)((SqsClientBuilder)((SqsClientBuilder)SqsClient.builder()
                .region(Region.of(this.awsRegion)))
                .credentialsProvider(() -> credentials))
                .build();
    }

    @Bean
    BidderService bidderService() {
        return new BidderService();
    }

    @Bean
    MessageQueueService messageQueueService() {
        return new MessageQueueService(sqsClient());
    }

    @Bean
    MessageNotificationService messageNotificationService() {
        return new MessageNotificationService(snsClient());
    }
}
