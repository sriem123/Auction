package edu.elon.bhaggerty.AuctionBidder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctionBidderApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuctionBidderApplication.class, args);
	}

}
