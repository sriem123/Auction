package edu.elon.bhaggerty.AuctionBidder.services;


import com.fasterxml.jackson.databind.ObjectMapper;
import edu.elon.bhaggerty.AuctionBidder.models.Bid;
import edu.elon.bhaggerty.AuctionBidder.models.BidderInfo;
import edu.elon.bhaggerty.AuctionBidder.models.ForSaleItem;
import edu.elon.bhaggerty.AuctionBidder.models.WinningBidNotification;
import edu.elon.bhaggerty.AuctionBidder.models.notification.NotificationMessage;
import edu.elon.bhaggerty.AuctionBidder.models.notification.NotificationMessageAttribute;
import edu.elon.bhaggerty.AuctionBidder.models.policy.SubscriptionQueuePolicy;
import edu.elon.bhaggerty.AuctionBidder.services.aws.MessageNotificationService;
import edu.elon.bhaggerty.AuctionBidder.services.aws.MessageQueueService;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.model.Message;

@Service
@PropertySources({@PropertySource({"classpath:application.properties"}), @PropertySource(value = {"file:application.properties"}, ignoreResourceNotFound = true)})
public class BidderService {
    @Value("${bidderName}")
    private String bidderName;

    @Value("${forSaleArn}")
    private String forSaleArn;

    @Value("${auctionCompleteArn}")
    private String auctionCompleteArn;

    @Value("${categories}")
    private String filterCategories;

    @Value("${bidderEmail}")
    private String bidderEmail;

    @Autowired
    private MessageQueueService messageQueueService;

    @Autowired
    private MessageNotificationService messageNotificationService;

    private double accountBalance = 100.0D;

    private Map<String, Bid> bidMap = new HashMap<>();

    private Map<String, WinningBidNotification> wonBidMap = new HashMap<>();

    private BidderInfo cleanupBidderInfo = null;

    public void runBidderProcess() {
        System.out.println("Starting Bidder Process for " + this.bidderName);
        BidderInfo bidderInfo = setupBidder();
        System.out.println("Waiting for Bids");
        try {
            while (this.accountBalance > 0.0D || this.bidMap.size() > 0) {
                Thread.sleep(20000L);
                bidOnItems(bidderInfo);
                if (this.bidMap.size() > 0) {
                    checkAcceptedBids(bidderInfo.getAcceptedBidsQueueUrl());
                    checkClosedAuctions(bidderInfo.getAuctionCompleteMessageQueueUrl());
                }
            }
            System.out.println("Out of Money. Exiting the process");
            cleanupQueues();
        } catch (InterruptedException interruptedException) {}
    }

    private BidderInfo setupBidder() {
        String acceptedBidsQueueUrl = createBidAcceptanceQueue();
        String forSaleMessageQueueUrl = createSubscriptionQueue("subscription_queue");
        Map<String, List> filterMap = buildAttributeFilters("category", this.filterCategories);
        String subscriptionId = subscribeToTopic(this.forSaleArn, forSaleMessageQueueUrl, filterMap);
        String auctionCompleteMessageQueueUrl = createSubscriptionQueue("auction_complete_queue");
        String auctionCompleteSubscriptionId = subscribeToTopic(this.auctionCompleteArn, auctionCompleteMessageQueueUrl, null);
        BidderInfo bidderInfo = new BidderInfo();
        bidderInfo.setAcceptedBidsQueueUrl(acceptedBidsQueueUrl);
        bidderInfo.setForSaleMessageQueueUrl(forSaleMessageQueueUrl);
        bidderInfo.setForSaleSubscriptionId(subscriptionId);
        bidderInfo.setAuctionCompleteMessageQueueUrl(auctionCompleteMessageQueueUrl);
        bidderInfo.setAuctionCompleteSubscriptionId(auctionCompleteSubscriptionId);
        this.cleanupBidderInfo = bidderInfo;
        return bidderInfo;
    }

    private String createBidAcceptanceQueue() {
        String queueName = this.bidderName + "_accepted_bids_queue";
        return this.messageQueueService.createMessageQueue(queueName, Integer.valueOf(30));
    }

    private String createSubscriptionQueue(String queueSuffice) {
        String queueName = this.bidderName + "_" + this.bidderName;
        return this.messageQueueService.createMessageQueue(queueName, Integer.valueOf(30));
    }

    private String subscribeToTopic(String topicArn, String messageQueueUrl, Map<String, List> filterMap) {
        String queueArn = this.messageQueueService.getQueueArnFromUrl(messageQueueUrl);
        SubscriptionQueuePolicy policy = new SubscriptionQueuePolicy(topicArn, queueArn);
        this.messageQueueService.addPolicy(messageQueueUrl, policy.getPolicyDocument());
        String subscriptionArn = this.messageNotificationService.createSubscription(topicArn, "sqs", queueArn, null);
        if (filterMap != null)
            filterTopic(subscriptionArn, filterMap);
        return subscriptionArn;
    }

    private void filterTopic(String subscriptionArn, Map<String, List> filterMap) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            String filterString = mapper.writeValueAsString(filterMap);
            this.messageNotificationService.SetSubscriptionAttribute(subscriptionArn, "FilterPolicy", filterString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Map<String, List> buildAttributeFilters(String attributeKey, String attributeFilters) {
        Map<String, List> filterMap = new HashMap<>();
        List<String> attributeFilterList = Arrays.asList(attributeFilters.split(","));
        filterMap.put(attributeKey, attributeFilterList);
        return filterMap;
    }

    private void bidOnItems(BidderInfo bidderInfo) {
        System.out.println("Looking for items to bid on");
        List<Message> messagesToBidOn = this.messageQueueService.readMessages(bidderInfo.getForSaleMessageQueueUrl());
        if (messagesToBidOn.size() == 0) {
            System.out.println("Nothing available to bid on");
        } else {
            messagesToBidOn.forEach(bidMessage -> {
                createBid(bidMessage, bidderInfo.getAcceptedBidsQueueUrl());
                this.messageQueueService.deleteMessageFromQueue(bidderInfo.getForSaleMessageQueueUrl(), bidMessage.receiptHandle());
            });
            System.out.println("Account Balance is " + String.format("%.2f", new Object[] { Double.valueOf(this.accountBalance) }));
        }
    }

    private void createBid(Message bidMessage, String acceptanceQueueUrl) {
        NotificationMessage bidNotification = convertToNotificationMessageObject(bidMessage.body());
        ForSaleItem forSaleItem = new ForSaleItem();
        forSaleItem.setAuctionId(((NotificationMessageAttribute)bidNotification.getMessageAttributes().get("auctionId")).getValue());
        forSaleItem.setBidQueueUrl(((NotificationMessageAttribute)bidNotification.getMessageAttributes().get("queue")).getValue());
        forSaleItem.setProductTitle(bidNotification.getSubject());
        forSaleItem.setDescription(bidNotification.getMessage());
        Bid bid = new Bid();
        bid.setEmail(this.bidderEmail);
        bid.setBidAmount(generateRandomBidAmount(1.0D, this.accountBalance));
        if (this.accountBalance - bid.getBidAmount() > 0.0D) {
            this.accountBalance -= bid.getBidAmount();
            bid.setAcceptanceQueueURL(acceptanceQueueUrl);
            if (submitBid(forSaleItem.getBidQueueUrl(), bid)) {
                this.bidMap.put(forSaleItem.getAuctionId(), bid);
                System.out.println("Submitted bid for Auction Id " + forSaleItem.getAuctionId() + " The bid was " + String.format("%.2f", new Object[] { Double.valueOf(bid.getBidAmount()) }) + " for " + forSaleItem.getDescription());
            }
        } else {
            System.out.println("Out of Money. Cannot submit bid for Auction Id " + forSaleItem.getAuctionId() + " for " + forSaleItem.getDescription());
        }
    }

    private boolean submitBid(String bidQueueUrl, Bid bid) {
        String messageBody = convertObjectToJson(bid);
        if (this.messageQueueService.doesQueueExist(bidQueueUrl)) {
            this.messageQueueService.writeMessageToQueue(bidQueueUrl, messageBody);
            return true;
        }
        System.out.println("Queue " + bidQueueUrl + " does not exist");
        this.accountBalance += bid.getBidAmount();
        return false;
    }

    public void checkAcceptedBids(String acceptedBidsQueueUrl) {
        System.out.println("Looking for accepted bids");
        List<Message> messagesAcceptedBids = this.messageQueueService.readMessages(acceptedBidsQueueUrl);
        if (messagesAcceptedBids.size() == 0) {
            System.out.println("No bids have been accepted");
        } else {
            messagesAcceptedBids.forEach(acceptedBidMessage -> {
                processAcceptedBid(acceptedBidMessage);
                this.messageQueueService.deleteMessageFromQueue(acceptedBidsQueueUrl, acceptedBidMessage.receiptHandle());
            });
        }
    }

    private void processAcceptedBid(Message bidMessage) {
        WinningBidNotification winningBidNotification = convertToWinningBidNotificationObject(bidMessage.body());
        this.wonBidMap.put(winningBidNotification.getAuctionId(), winningBidNotification);
        System.out.println("I won auction " + winningBidNotification.getAuctionId() + " with a price of " + winningBidNotification.getAmountOfBid());
    }

    private void checkClosedAuctions(String auctionCompleteMessageUrl) {
        System.out.println("Looking for closed auctions");
        List<Message> messagesClosedAuctions = this.messageQueueService.readMessages(auctionCompleteMessageUrl);
        if (messagesClosedAuctions.size() > 0)
            messagesClosedAuctions.forEach(closedAuctionMessage -> {
                closeAuction(closedAuctionMessage);
                this.messageQueueService.deleteMessageFromQueue(auctionCompleteMessageUrl, closedAuctionMessage.receiptHandle());
            });
    }

    private void closeAuction(Message closedAuctionMessage) {
        NotificationMessage closedAuctionNotification = convertToNotificationMessageObject(closedAuctionMessage.body());
        String auctionId = ((NotificationMessageAttribute)closedAuctionNotification.getMessageAttributes().get("auctionId")).getValue();
        String message = closedAuctionNotification.getMessage();
        if (this.bidMap.containsKey(auctionId)) {
            if (!this.wonBidMap.containsKey(auctionId)) {
                System.out.println("Auction completed for " + auctionId + " " + message);
                this.accountBalance += ((Bid)this.bidMap.get(auctionId)).getBidAmount();
                System.out.println("Account Balance is now " + String.format("%.2f", new Object[] { Double.valueOf(this.accountBalance) }));
            }
            this.bidMap.remove(auctionId);
        }
    }

    private NotificationMessage convertToNotificationMessageObject(String notificationMessageString) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            NotificationMessage notification = (NotificationMessage)mapper.readValue(notificationMessageString, NotificationMessage.class);
            return notification;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private WinningBidNotification convertToWinningBidNotificationObject(String messageString) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            WinningBidNotification winningBidNotification = (WinningBidNotification)mapper.readValue(messageString, WinningBidNotification.class);
            return winningBidNotification;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void cleanupQueues() {
        if (this.cleanupBidderInfo != null) {
            this.messageNotificationService.unsubscribe(this.cleanupBidderInfo.getForSaleSubscriptionId());
            this.messageNotificationService.unsubscribe(this.cleanupBidderInfo.getAuctionCompleteSubscriptionId());
            this.messageQueueService.deleteMessageQueue(this.cleanupBidderInfo.getForSaleMessageQueueUrl());
            this.messageQueueService.deleteMessageQueue(this.cleanupBidderInfo.getAuctionCompleteMessageQueueUrl());
            this.messageQueueService.deleteMessageQueue(this.cleanupBidderInfo.getAcceptedBidsQueueUrl());
        }
    }

    private String convertObjectToJson(Object obj) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private double generateRandomBidAmount(double min, double max) {
        Random random = new Random();
        double randomValue = min + (max - min) * random.nextDouble();
        return Math.round(randomValue * 100.0D) / 100.0D;
    }
}

