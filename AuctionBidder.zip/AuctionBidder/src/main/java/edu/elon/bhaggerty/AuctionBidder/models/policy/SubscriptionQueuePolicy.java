package edu.elon.bhaggerty.AuctionBidder.models.policy;

import org.springframework.util.StringUtils;

public class SubscriptionQueuePolicy {
    private String topicArn;

    private String queueArn;

    public void setTopicArn(String topicArn) {
        this.topicArn = topicArn;
    }

    public void setQueueArn(String queueArn) {
        this.queueArn = queueArn;
    }

    public void setPolicyDocument(String policyDocument) {
        this.policyDocument = policyDocument;
    }

    public String getTopicArn() {
        return this.topicArn;
    }

    public String getQueueArn() {
        return this.queueArn;
    }

    private String policyDocument = "{\n    \"Version\": \"2012-10-17\",\n    \"Statement\": [\n        {\n            \"Sid\": \"topic-subscription-{topicArn}\",\n            \"Effect\": \"Allow\",\n            \"Principal\": {\n                \"AWS\": \"*\"\n            },\n            \"Action\": \"SQS:SendMessage\",\n            \"Resource\": \"{queueArn}\",\n            \"Condition\": {\n                \"ArnLike\": {\n                    \"aws:SourceArn\": \"{topicArn}\"\n                }\n            }\n        }\n    ]\n}";

    public String getPolicyDocument() {
        return this.policyDocument;
    }

    public SubscriptionQueuePolicy(String topicArn, String queueArn) {
        this.topicArn = topicArn;
        this.queueArn = queueArn;
        this.policyDocument = buildPolicy();
    }

    private String buildPolicy() {
        String policy = StringUtils.replace(this.policyDocument, "{topicArn}", this.topicArn);
        policy = StringUtils.replace(policy, "{queueArn}", this.queueArn);
        return policy;
    }

    public SubscriptionQueuePolicy() {}
}
