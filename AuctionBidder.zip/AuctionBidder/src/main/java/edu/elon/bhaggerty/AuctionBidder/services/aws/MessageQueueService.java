package edu.elon.bhaggerty.AuctionBidder.services.aws;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.CreateQueueRequest;
import software.amazon.awssdk.services.sqs.model.CreateQueueResponse;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import software.amazon.awssdk.services.sqs.model.DeleteMessageResponse;
import software.amazon.awssdk.services.sqs.model.DeleteQueueRequest;
import software.amazon.awssdk.services.sqs.model.DeleteQueueResponse;
import software.amazon.awssdk.services.sqs.model.GetQueueAttributesRequest;
import software.amazon.awssdk.services.sqs.model.GetQueueAttributesResponse;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.QueueAttributeName;
import software.amazon.awssdk.services.sqs.model.QueueDoesNotExistException;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;
import software.amazon.awssdk.services.sqs.model.SetQueueAttributesRequest;
import software.amazon.awssdk.services.sqs.model.SetQueueAttributesResponse;

@Service
public class MessageQueueService {
    private SqsClient sqsClient;

    @Autowired
    public MessageQueueService(SqsClient sqsClient) {
        this.sqsClient = sqsClient;
    }

    public String createMessageQueue(String queueName, Integer visibilityTimeout) {
        Map<QueueAttributeName, String> attributesMap = new HashMap<>();
        attributesMap.put(QueueAttributeName.VISIBILITY_TIMEOUT, visibilityTimeout.toString());
        CreateQueueRequest createQueueRequest = (CreateQueueRequest)CreateQueueRequest.builder().queueName(queueName).attributes(attributesMap).build();
        CreateQueueResponse response = this.sqsClient.createQueue(createQueueRequest);
        return response.queueUrl();
    }

    public void deleteMessageQueue(String queueURL) {
        DeleteQueueRequest deleteQueueRequest = (DeleteQueueRequest)DeleteQueueRequest.builder().queueUrl(queueURL).build();
        DeleteQueueResponse deleteQueueResponse = this.sqsClient.deleteQueue(deleteQueueRequest);
    }

    public List<Message> readMessages(String queueUrl) {
        List<Message> receivedMessages = new ArrayList<>();
        ReceiveMessageRequest receiveMessageRequest = (ReceiveMessageRequest)ReceiveMessageRequest.builder().queueUrl(queueUrl).waitTimeSeconds(Integer.valueOf(5)).maxNumberOfMessages(Integer.valueOf(10)).build();
        boolean stillMessages = true;
        while (stillMessages) {
            ReceiveMessageResponse receiveMessageResponse = this.sqsClient.receiveMessage(receiveMessageRequest);
            if (receiveMessageResponse.hasMessages()) {
                List<Message> newMessages = receiveMessageResponse.messages();
                receivedMessages.addAll(newMessages);
                continue;
            }
            stillMessages = false;
        }
        return receivedMessages;
    }

    public void deleteMessageFromQueue(String queueUrl, String receiptHandle) {
        DeleteMessageRequest deleteMessageRequest = (DeleteMessageRequest)DeleteMessageRequest.builder().queueUrl(queueUrl).receiptHandle(receiptHandle).build();
        DeleteMessageResponse deleteMessageResponse = this.sqsClient.deleteMessage(deleteMessageRequest);
    }

    public void writeMessageToQueue(String queueUrl, String messageBody) {
        SendMessageRequest sendMessageRequest = (SendMessageRequest)SendMessageRequest.builder().queueUrl(queueUrl).messageBody(messageBody).build();
        SendMessageResponse sendMessageResponse = this.sqsClient.sendMessage(sendMessageRequest);
    }

    public void addPolicy(String queueUrl, String policy) {
        Map<String, String> attributeMap = new HashMap<>();
        attributeMap.put("Policy", policy);
        SetQueueAttributesRequest setQueueAttributesRequest = (SetQueueAttributesRequest)SetQueueAttributesRequest.builder().queueUrl(queueUrl).attributesWithStrings(attributeMap).build();
        SetQueueAttributesResponse setQueueAttributesResponse = this.sqsClient.setQueueAttributes(setQueueAttributesRequest);
    }

    public String getQueueArnFromUrl(String queueUrl) {
        GetQueueAttributesRequest getQueueAttributesRequest = (GetQueueAttributesRequest)GetQueueAttributesRequest.builder().queueUrl(queueUrl).attributeNames(new QueueAttributeName[] { QueueAttributeName.QUEUE_ARN }).build();
        GetQueueAttributesResponse getQueueAttributesResponse = this.sqsClient.getQueueAttributes(getQueueAttributesRequest);
        Map<String, String> attributeMap = getQueueAttributesResponse.attributesAsStrings();
        return attributeMap.get(QueueAttributeName.QUEUE_ARN.toString());
    }

    public boolean doesQueueExist(String queueUrl) {
        try {
            GetQueueAttributesRequest request = (GetQueueAttributesRequest)GetQueueAttributesRequest.builder().queueUrl(queueUrl).build();
            this.sqsClient.getQueueAttributes(request);
            return true;
        } catch (QueueDoesNotExistException e) {
            return false;
        }
    }
}
