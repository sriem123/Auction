package edu.elon.bhaggerty.AuctionBidder.models;

public class ForSaleItem {
    private String auctionId;

    private String productTitle;

    private String productCategory;

    private String description;

    private int auctionLength;

    private String bidQueueUrl;

    private String notificationId;

    public void setAuctionId(String auctionId) {
        this.auctionId = auctionId;
    }

    public void setProductTitle(String productTitle) {
        this.productTitle = productTitle;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAuctionLength(int auctionLength) {
        this.auctionLength = auctionLength;
    }

    public void setBidQueueUrl(String bidQueueUrl) {
        this.bidQueueUrl = bidQueueUrl;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public String getAuctionId() {
        return this.auctionId;
    }

    public String getProductTitle() {
        return this.productTitle;
    }

    public String getProductCategory() {
        return this.productCategory;
    }

    public String getDescription() {
        return this.description;
    }

    public int getAuctionLength() {
        return this.auctionLength;
    }

    public String getBidQueueUrl() {
        return this.bidQueueUrl;
    }

    public String getNotificationId() {
        return this.notificationId;
    }
}