package edu.elon.bhaggerty.AuctionBidder.models;

public class WinningBidNotification {
    private String auctionId;

    private double amountOfBid;

    public WinningBidNotification() {}

    public WinningBidNotification(String auctionId, double amountOfBid) {
        this.auctionId = auctionId;
        this.amountOfBid = amountOfBid;
    }

    public void setAuctionId(String auctionId) {
        this.auctionId = auctionId;
    }

    public void setAmountOfBid(double amountOfBid) {
        this.amountOfBid = amountOfBid;
    }

    public String getAuctionId() {
        return this.auctionId;
    }

    public double getAmountOfBid() {
        return this.amountOfBid;
    }
}